package com.ontimize.atomicHotelsApiRest.api.core.exceptions;

public class LiadaPardaException extends Exception{

	public LiadaPardaException() {
		super();
	}
	public LiadaPardaException(String msg) {		
		super(msg);
	}
}
